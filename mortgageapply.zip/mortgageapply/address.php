
             <div id="step2" class="stepquestion" data-rel="page">
            <h4>Where do you live?</h4>
          <form name="address" action="index.php" method="post">
            <label for="street">Street:</label><input type="text" maxlength="100" name="street" />
            <label for="city">City:</label><input type="text" maxlength="100" name="city" />
            <label for="zip">Zip:</label><input type="text" maxlength="10" name="zip" onkeypress="return changeSteps(event, '#step2', '#step3');"/>

          </form>

          </div>





