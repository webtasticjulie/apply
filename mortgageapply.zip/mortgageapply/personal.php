    <div data-role="header">
        <h1>
            Personal
        </h1>
    </div>
    <script type="text/javascript" src="js/validate.js"></script>
    <div class="progressbar">
        <div></div>
    </div>
    <div class="borrowertab">
        <?php include('tabs.html');?>
        <div style="clear: left;"></div>
        <?php
            require_once('classes/account.class.php');
            $account = new account;
            $account->check_loggedin(); ?>
    		<form name="personalinfo" method="post" action="index.php">
        		<h2>Personal</h2>
    			<hr/>
    			<input type="hidden" name="formname" value="personal"/>
    			<input type="submit" value="Next" name="personalsubmit" data-mini="true" data-icon="arrow-r"/>

    		</form>
	</div>

