<div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
</div>
<div data-role="content">
    <div class="centercol">

       <form method="post" action="c.php" enctype="multipart/form-data" name="contactus">


       <label for="fname"><strong>Name:</strong></label><input type="text" name="fname" value="" required/>
	   <label for="filesToUpload"><strong>Attachment(s):</strong><br/>(Select multiple files by holding the CTRL key)</label><input name="filesToUpload[]" id="filesToUpload" type="file" multiple="" />
       <div id="selectedFiles"></div>
       <br/>
	   <label for="message"><strong>Message:</strong></label><textarea name="message" rows="50" id="message"></textarea>
	   <input type="submit" name="SendMessage" value="Send Message" />
	   </form>
       <script>
        var selDiv = "";

        document.addEventListener("DOMContentLoaded", init, false);

        function init() {
            document.querySelector('#filesToUpload').addEventListener('change', handleFileSelect, false);
            selDiv = document.querySelector("#selectedFiles");
        }

        function handleFileSelect(e) {

            if(!e.target.files) return;

            selDiv.innerHTML = "";

            var files = e.target.files;
            for(var i=0; i<files.length; i++) {
                var f = files[i];

                selDiv.innerHTML += f.name + "<br/>";

            }

        }
        </script>
	</div>
    </div>
    <div data-role="footer"></div>