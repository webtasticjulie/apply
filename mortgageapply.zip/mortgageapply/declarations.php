<div data-role="header">
        <h1>
          Declarations
        </h1>
</div>

<div class="progressbar">
    <div></div>
</div>

<div class="borrowertab">
    <?php include('tabs.html');?>
    <div style="clear: left;"></div>
    <?php
    require_once('classes/account.class.php');
    $account = new account;
    $account->check_loggedin(); ?>
	<form name="declarations" action="index.php" method="post" style="width: 75%; margin-right: auto; margin-left: auto;padding-top: 2em;">

        <input type="hidden" name="formname" value="declarations"/>
        <fieldset style="border: 1px solid #1E578E;padding: 2em;">
            <legend>Declarations</legend>
            <?php
            require_once('classes/declaration.class.php');
		    $declaration = new declaration;
            $declaration->get_declarations();
            ?>
        </fieldset>
        <br/><br/>
        <fieldset style="border: 1px solid #1E578E;padding: 2em;font-weight: bold;">
            <legend>Information for Government Monitoring</legend>
            <strong>Borrower</strong><hr/>
            <label for="optout">I do not wish to provide this information<input type="checkbox" name="optout" id="optout"  onchange='hideme("#hideme");'/></label>
            <div id="hideme">
            <?php $declaration->get_ethnicity();
            $declaration->get_sex();
            $declaration->get_race();
            ?>
            </div>
        </fieldset>
        <input type="submit" name="declarations" value="Next" />
	</form>
</div>
