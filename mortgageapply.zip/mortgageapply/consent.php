<div data-role="header">
    <h1>
        Consent
    </h1>
</div>



<div class="progressbar">
     <div></div>
</div>

<div class="borrowertab" >
        <?php include('tabs.html');?>
        <div style="clear: left;"></div>
        <?php
        require_once('classes/account.class.php');
        $account = new account;
        $account->check_loggedin(); ?>
	    <br/><br/>
	    <div id="consentdiv" style="padding: 10px; width: 75%; margin-right: auto; margin-left:auto;">
	        <form name="consents" action="index.php" method="post">
        		 <label for="creditcheck">*Credit Check Authorization:</label>
        		 <textarea name="creditcheck" id="creditcheck" readonly>During your mortgage loan application process, this institution performs a Credit Check that requires us to obtain and confirm information regarding your personal and financial background. This Credit Check includes, but is not limited to, your marital status, number of dependents, current and past employers, current deposit accounts, current and past consumer credit accounts, and your mortgage and/or rental history.</textarea>


        		 <label for="agreecreditcheck" >I&nbsp;agree to the Credit Check Authorization</label>
        		 <input type="checkbox" id="agreecreditcheck" name="agreecreditcheck" data-mini="true" value="agree" title="You must agree to the Credit Check Authorization" required>
                 <br/>

        		 <label for="patriotact">*Patriot Act Agreement:</label>
                 <textarea name="patriotact" id="patriotact" readonly>In accordance with Federal regulations set forth in the USA Patriot Act, this institution is required to verify the identity of any person applying for a mortgage loan to the extent reasonable and practicable, and maintain records of the information used to verify their identity. During your mortgage loan application process, we will require your name, current and past home addresses, date of birth, and other identifying information about you.
            	 </textarea>

        		<label for="patriotactcheck">I&nbsp;agree to the Patriot Act Agreement</label>
        		<input type="checkbox" id="patriotactcheck" name="patriotact" data-mini="true" value="agree" title="You must agree to the Patriot Act Agreement" required>
                <br/>

               <label for="electronic">*Authorization to Receive Electronic Disclosures:</label>
        	   <textarea name="electronic" id="electronic" data-mini="true" readonly>In order to successfully process your mortgage loan application, you must agree to receive certain disclosures from this institution in electronic form rather than paper form. You must also agree to the terms of the eDisclosure Agreement, which include software and hardware requirements and your responsibility to maintain and provide a valid email address. Certain disclosures may be provided to you in paper form as necessary once your mortgage loan application is received.
               </textarea>

               <label for="electroniccheck">I&nbsp;agree to Receive Electronic Disclosures</label>
        	   <input type="checkbox" id="electroniccheck" name="electroniccheck" data-mini="true" value="agree" title="You must agree to Receive Electronic Disclosures" required>
        	   <br/>

        	   <label for="privacypolicy">*Privacy Policy:</label>
        	   <textarea name="privacypolicy" id="privacypolicy" data-mini="true" readonly>We take our clients' financial privacy very seriously. During the course of processing your application, we accumulate non-public personal financial information from you and from other sources about your income, your assets, and your credit history in order to allow a lender to make an informed decision about granting you credit. We restrict access to nonpublic personal information about you to those employees who need to know that information to provide products or services to you. We maintain physical, electronic, and procedural safeguards that comply with federal regulations to guard your nonpublic personal information.

                We collect nonpublic information about you from the following sources: (i) information we receive from you on applications or other forms; (ii) information about your transactions with us, our affiliates, or others; and (iii) information we receive from a consumer reporting agency.

                We do not disclose any nonpublic information about our customers or former customers to any third party, except as permitted by law.  </textarea>

                <label for="privacycheck">I&nbsp;agree to the Privacy Policy</label>
        	    <input type="checkbox" id="privacycheck" name="privacycheck" data-mini="true" value="agree" title="You must agree to the Privacy Policy" required>
	            <br/>

        	   <label for="ECOA">I/We acknowlege receipt of the ECOA</label>
        	   <input type="checkbox" id="ECOA" name="ECOA" data-mini="true" value="agree" title="You must acknowledge the receipt of the ECOA" required>

        	   <label for="respacheck">I/We acknowledge receipt of the RESPA Servicing Transfer Disclosure</label>
        	   <input type="checkbox" id="respacheck" name="respacheck" data-mini="true" title="You must acknowledge the receipt of the RESPA Servicing Transfer Disclosure" value="agree"/>
               <br/>


        	   <fieldset data-role="controlgroup">
                    <input type="radio" name="copyoption" id="print" value="print" checked="checked" />
             	    <label for="print">I will print or save the disclosure</label>

             	    <input type="radio" name="copyoption" id="mail" value="mail"  />
             	    <label for="mail">Mail a paper copy to me</label>

             	    <input type="radio" name="copyoption" id="printmail" value="printmail"  />
             	    <label for="printmail">I will print or save the disclosure and would like a copy mailed to me</label>


        	  </fieldset>
        	  <input type="hidden" name="formname" value="consent"/>
        	  <input type="submit" name="consent" value="Next"/>
            </form>
	    </div>
</div>