<div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
</div>
<div data-role="content">
<div style="width: 50%; margin-right: auto; margin-left: auto;">
<h3><strong>The following items are needed to process your application:</strong></h3>

    <ul data-role="listview" class="tasklist" data-filter="false" data-filter-reveal="false">
      <li data-icon="check" class="check">Driver's Licence<p>Please Provide a copy of your driver's license</p> </li>
      <li data-icon="plus" class="reviewitem">Please supply your W2s for 2015<p>Please Provide a copy of your W2s</p> </li>
      <li data-icon="plus" class="reviewitem">Please supply a copy of your Birth Certificate<p>Please Provide a copy of your birth certificate</p> </li>
      <li data-icon="plus" class="reviewitem">Please supply a copy of child support order<p>Please Provide a copy of the child support order</p> </li>

    </ul>

    <br/><a href="index.php#contact"  data-transition="slide" data-role="button" data-mini="true">Upload Now</a>
    </div>
</div>
<div data-role="footer" style="text-align: center; width: 100%; position: absolute; bottom: 0px;"><br/>&copy;Homestar Financial 2016<br/><br/></div>