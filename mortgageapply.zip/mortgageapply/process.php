<?php
 foreach($_POST as $key=>$value){    //iterate through post values and save to session
                 $_SESSION[$key]=$value;
                 //echo "Saving ".$key." as ".$value."<br/>";
 }

 if ($_POST['formname']=="step3c"){
     // check if draft has already been saved for this session
    if (($_SESSION['draft_created']!=true) AND ($_SESSION['app_id']=="")){
       require_once('classes/borrower.class.php');

	   $borrower = new borrower;
       $app_id = $borrower->add_application('draft');
       $borrower->add_borrower($_SESSION['fname'], $_SESSION['lname'], $_SESSION['middleinit'], $_SESSION['street'], $_SESSION['zip'], $_SESSION['city'], $_SESSION['state'], $_SESSION['mobilephone'], $_SESSION['homephone'], $_SESSION['email'], $_SESSION['dob'],'n', $app_id);
       $_SESSION['app_id']=$app_id;
       $_SESSION['draft_created']=true;
    }

 }  else{
     echo "invalid form name julie".$_POST['formname'];
 }





?>
