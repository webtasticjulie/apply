<div data-role="header">
         <h1>
          Employment
        </h1>
</div>
<script type="text/javascript" src="js/validate.js"></script>


       <div class="progressbar">
            <div></div>
       </div>
       <div class="borrowertab">
	       <?php include('tabs.html');?>
	       <?php //print_r($_SESSION);?>
		   <div style="clear: left;"></div>
             <?php
           require_once('classes/account.class.php');
           $account = new account;
           $account->check_loggedin();

          //echo "<h4>Session</h4><hr/>";
         // print_r($_SESSION);
          ?>
		   <form name="employmentinfo" method="post" action="index.php" style="width: 85%; margin-left: auto; margin-right: auto;" >
           <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
           <legend>Employment Information</legend>
                <div class="leftcol">

                <label for="employername">Employer Name:<input type="text" name="employername" id="employername" value="<?php echo $_SESSION['employername'];?>" maxlength="100" data-mini="true" tabindex="1" required /></label>
                <label for="employeraddress">Address:<input type="text" name="employeraddress" id="employeraddress" value="<?php echo $_SESSION['employeraddress'];?>" maxlength="100" data-mini="true" tabindex="2" required /></label>
                <label for="employercity">City: <input type="text" name="employercity" id="employercity" value="<?php echo $_SESSION['employercity'];?>" maxlength="100" data-mini="true" tabindex="3" required/></label>
                <label for="employmentstate">State: <select name="employmentstate" id="employmentstate" data-mini="true"  tabindex="6">
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Deleware</option>
                        <option value="FL">Florida</option>
                        <option value="GA" selected>Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                      </select></label><br/>
                <label for="employerzip">Zip: <input type="text" name="employerzip" id="employerzip" value="<?php echo $_SESSION['employerzip'];?>" maxlength="15" tabindex="4" data-mini="true" required/></label>
                <label for="businessphone">Business Phone:</label><input type="text" name="businessphone" id="businessphone" value="<?php echo $_SESSION['businessphone'];?>" maxlength="20" tabindex="5" data-mini="true"/>
                <label for="extension">Ext:</label><input type="text" maxlength="6" value="<?php echo $_SESSION['extension'];?>" name="extension" id="extension">
                </div>
                <div class="rightcol">
                <label for="position">Position/Title/Type of Business:<input type="text" name="position" id="position" value="<?php echo $_SESSION['employmenttitle'];?>" tabindex="5" maxlength="100" data-mini="true" required/></label>
                <label for="startdate">Start Date:<input type="date" name="startdate" id="startdate" tabindex="6" required/></label>
                <label for="selfemployed">Self-Employed:</label><select name="selfemployed" id="selfemployed" data-role="slider" data-mini="true"><option value="yes">Yes</option><option value="no">No</option></select>
                <label for="yearsemployedprof">Years employed in this line of work/profession: <input type="number" tabindex="8" name="yearsemployedprof" id="yearsemployedprof" required/></label>

                </div>
                <input type="hidden" name="formname" value="employment"/>
                <br/><br/>
				<input type="submit" value="Next" name="employmentsubmit" tabindex="9"/>
              </fieldset>
			</form>

		</div>

