<?php
if (!isset($_SESSION)) {
  session_start("checklist");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon"/>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <title>
      Homestar Financial
    </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src= "//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    <script type="text/javascript" src="js/addmore.js"></script>
    <script type="text/javascript" src="js/addmorejq.js"></script>
    <script type="text/javascript">
    $(document).ready(function(){
        $("form[name*='step']").submit(function(){
            var stepno = ($(this).attr("name").match(/\d+/));
            var nextstep = +stepno + 1;
            var values = $(this).serialize();
            $.ajax({
                url: "process.php",
                type: "post",
                data: values ,
                success: function (response) {
                    var step= "#step" + nextstep + "<?php echo $_SESSION["coborroweropt"];?>";
                    if( $(step).length )
                    {
                        // it exists
                        changePages(step);
                    }else{
                        //assume at end
                        changePages('#summary');
                    }
                },
                error: function(jqXHR, textStatus, errorThrown) {
                   console.log(textStatus, errorThrown);
                }
            });
            return false;
        });


    });


    $(function() {
        $( ".progressbar" ).progressbar({
          value:60
        });

    });

    $(function() {
        $( "#allsteps" ).sortable();
        $( "#allsteps" ).disableSelection();
    });

    $(function(){
         $('#elements').sortable({
            axis: 'y',
            update: function (event, ui) {
                var data = $(this).sortable('serialize');

                // POST to server using $.post or $.ajax
                $.ajax({
                    data: data,
                    type: 'POST',
                    url: 'organize.php'
                });

            }
        });

    });



    </script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="css/steps.css">
   </head>
  <body>




    <div data-role="page" id="homepage">
      	<?php include('home.php');?>
    </div>
       <!--Create account page-->
    <div data-role="page" id="account">
    	<?php include ('create.php');?>
    </div>

    <div data-role="page" id="lost">
         <?php include('lost.php');?>
    </div>

    <!--landing page-->
    <div data-role="page" id="loggedin_landingpage">
      <?php include('landingpage.php');?>
    </div>

       <!--contact us page-->
    <div data-role="page" id="contact">
    	<?php include('contact.php');?>
	</div>

    <!-- Login Page -->
    <div data-role="page" id="login">
      <?php include('login.php');?>
    </div>

    <!-- Logout Page-->
    <div data-role="page" id="logout">
          <?php include("logout.php");?>
    </div>



    <!--manage steps sortable-->
    <div data-role="page" id="managesteps">
          <div data-role="header">Manage Steps</div>
          <div data-role="content">
          <?php require_once('classes/steps.class.php');

            $steps=new steps;
            $steps->get_all_steps();

          ?>

          <ul id="elements">
          <li class='ui-state-default'><span class='ui-icon ui-icon-arrowthick-2-n-s'></span>Julies</li>
          <li class='ui-state-default'><span class='ui-icon ui-icon-arrowthick-2-n-s'></span>Test</li>
          <li class='ui-state-default'><span class='ui-icon ui-icon-arrowthick-2-n-s'></span>Sortable</li>
          </ul>
          </div>
          <div data-role="footer"></div>
    </div>
    <div data-role="page" id="mytasks">
            <?php include("tasks.php");?>
    </div>
    <div data-role="page" id="step0">
        <div data-role="header">
            <h1 style="font-size: 2em; color: #1E578E;">
                Homestar
            </h1>
        </div>
        <div data-role="content">
            <div class="stepquestion">
         <span class="stepquestionheader"><h3>Coborrower</h3></span>
         <span class="question">
           <p>Before we begin the application, please answer:</p>
             <form name="coborrower"  name="step0" id="form_step0" method="POST" action="" >
                 <input type="hidden" name="formname" value="step0"/>
                 <label for="coborroweropt">Will you have a coborrower?
                     <span style="float:right;">
                        <select data-role="slider" id="coborroweropt" name="coborroweropt">
                            <option value="c">Yes</option>
                            <option value="a">No</option>
                        </select>
                     </span>
                      <br/><br/><br/>
                     <hr/>
                 </label>
                 <input type="submit" name="coborroweroption" value="Continue"/>
             </form>
             </span>
             </div>
         </div>
         <div data-role="footer"></div>
    </div>
    <!-- dynamically generate div with data role of page for each step in database-->
    <?php


        require_once('classes/steps.class.php');
        $steps=new steps;
        $steps->get_steps();

    ?>
     <div data-role="page" id="summary">
        <?php include("summary.php");?>
    </div>

    <!-- Final Completion Page -->
    <div data-role="page" id="complete">
        <?php include("complete.php");?>
    </div>









    <div data-role="footer">
    </div>
  </body>
</html>
