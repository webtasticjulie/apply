<div data-role="header">
        <h1>
         My Account
        </h1>
</div>

<form name="createaccount" id="createaccount" action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
    <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px;width: 75%; margin-right: auto; margin-left: auto; box-shadow: 10px 10px 5px #888888;">
        <legend>Create Account:</legend>
        <div class="centercol">
           Username: <input type="text" name="username" placeholder="Username" maxlength="50" tabindex="1" required><br>
           First Name: <input type="text" name="firstname" placeholder="First Name" maxlength="100" tabindex="2" required><br>
           Last Name: <input type="text" name="lastname" placeholder="Last Name" maxlength="100" tabindex="3" required><br>
           Password: <input type="password" name="password" placeholder="Password" maxlength="100" tabindex="4" required><br>
           Confirm Password: <input type="password" name="confirmpassword" placeholder="Confirm Password" maxlength="100" tabindex="5" required><br>
           Email: <input type="email" name="email" placeholder="Email" maxlength="100" tabindex="6" required><br>
           Confirm Email: <input type="email" name="confirmemail" placeholder="Email" maxlength="100" tabindex="7" required><br>

        <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 10px;">
        <legend>Security Questions</legend>
        <p>Please select 3 security questions. In the event you forget your password, these will be used to retrieve your information</p>
            <?php
            require_once('classes/account.class.php');
            $account = new account;
            ?>
            <select name="securityquestions1" tabindex="8">
                <option id="securityquestions1" >SELECT</option>
                <?php $account->get_questions('securityquestions1', false, 1); ?>
            </select>
            Answer to security question:<input type="text" name="securityquestion_answer1" maxlength="100" tabindex="9" required><br>
            <select name="securityquestions2" tabindex="10">
                <option id="securityquestions2">SELECT</option>
                <?php $account->get_questions('securityquestions2', false, 1);   ?>
            </select>
            Answer to security question:<input type="text" name="securityquestion_answer2" maxlength="100" tabindex="11" required><br>
            <select name="securityquestions3" tabindex="12">
                <option id="securityquestions3">SELECT</option>
                <?php $account->get_questions('securityquestions3', false, 1);   ?>
            </select>
            Answer to security question:<input type="text" name="securityquestion_answer3" maxlength="100" tabindex="12" required><br>
        </fieldset>
        <input type="hidden" name="createaccount" value="createaccount"/>
        <input type="submit" class="ui-btn ui-corner-all ui-btn-inline" value="Create Account" tabindex="13" name="submit"/>
        </div>
    </fieldset>
</form>