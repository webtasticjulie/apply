<?php
require_once('applications.class.php');
class loan extends applications{
     var $fname;
	 var $lname;
	 var $mi;
	 var $zip;
	 var $city;
	 var $mobile;
	 var $home;
     var $email;
     var $dob;
     var $street;
     var $state;


	function view_loan(){
        include('loaninfo_template.php');
	} //fu

    function create_loan($fname, $lname, $mi, $street, $zip, $city, $state, $mobile, $home, $email, $dob){
            $this->set_var('fname', $fname);
            $this->set_var('lname', $lname);
            $this->set_var('mi', $mi);
            $this->set_var('zip', $zip);
            $this->set_var('city', $city);
            $this->set_var('state', $state);
            $this->set_var('mobile', $mobile);
            $this->set_var('home', $home);
            $this->set_var('street', $street);
            $this->set_var('email', $email);
            $this->set_var('dob', $dob);

    } //fu

} //end of class
?>
