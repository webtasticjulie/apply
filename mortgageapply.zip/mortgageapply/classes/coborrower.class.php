<?php
require_once ('applications.class.php');
class coborrower extends applications{
    var $cofname;
	var $colname;
	var $comi;
	var $cozip;
	var $cocity;
	var $comobile;
	var $cohome;


	function view_coborrower(){
        include('templates/coborrower_template.php');
	}//fu
    function create_coborrower($fname, $lname, $mi, $street, $zip, $city, $state, $mobile, $home, $email, $dob){
            $this->set_var('cofname', $fname);
            $this->set_var('colname', $lname);
            $this->set_var('comi', $mi);
            $this->set_var('cozip', $zip);
            $this->set_var('cocity', $city);
            $this->set_var('costate', $state);
            $this->set_var('comobile', $mobile);
            $this->set_var('cohome', $home);
            $this->set_var('costreet', $street);
            $this->set_var('coemail', $email);
            $this->set_var('codob', $dob);

    }//fu

}//end of class
?>
