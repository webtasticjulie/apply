<?php
require_once('applications.class.php');
class declaration extends applications{

       function get_declarations(){
           $link = $this->connectdb();
           $sql = "SELECT dec_id,dec_question FROM declarations";
           $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);

            if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found ";
                    //log error
            } else {

                    mysqli_stmt_bind_result($query, $dec_id, $dec_questions);
                    $x=0;

                    while (mysqli_stmt_fetch($query)) {
                       echo "
                      <div data-role=\"fieldcontain\">
                            <label for=\"decquestions".$dec_id."\" style=\"width: 90%;\">".$dec_questions."</label>
                        	<select name=\"slider\" id=\"decquestions".$dec_id."\" data-role=\"slider\">
                        		<option value=\"no\">No</option>
                        		<option value=\"yes\">Yes</option>
                        	</select>
                      </div>  ";
                      $x++;

                    }
            }

            mysqli_stmt_close($query);
            mysqli_close($link);
       }  //fu
       function get_ethnicity(){
            $link = $this->connectdb();
            $sql = "SELECT ethnicity_id, ethnicity_desc FROM ethnicity";
            $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);

            if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found ";
                    //log error
            } else {

                    mysqli_stmt_bind_result($query, $eth_id, $eth_desc);
                    $x=0;
                    echo "<label for='ethnicity'>Ethnicity</label><select name='ethnicity' id='ethnicity' data-mini='true'>";
                    echo "<option value=''>Select</option>";
                    while (mysqli_stmt_fetch($query)) {
                       echo "<option value=\"".$eth_id."\">".$eth_desc."</option>";

                    }
                    echo "</select>";
            }


       }//fu

       function get_sex(){
           echo "<label for='sex'>Sex</label><select name='sex' id='sex' data-mini='true'><option value=''>Select</option><option value='female'>Female</option><option value='male'>Male</option></select>";
       }
       function get_race(){
            $link = $this->connectdb();
            $sql = "SELECT race_id, race_desc FROM race";
            $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
            mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
            mysqli_stmt_store_result($query);
            if( mysqli_stmt_num_rows($query) == 0){
                echo "No entries found ";
                //log error
            } else {

                mysqli_stmt_bind_result($query, $race_id, $race_desc);
                $x=0;
                echo "<label for='race'>Race</label><select name='race' id='race' data-mini='true'>";
                echo "<option value=''>Select</option>";
                while (mysqli_stmt_fetch($query)) {
                    echo "<option value=\"".$race_id."\">".$race_desc."</option>";
                }
                echo "</select>";
            }


       }//fu

}
?>
