<?php
//assets.class.php extends applications
require_once('applications.class.php');
class assets extends applications{


    // template file to view assets on summary page
	function view_assets(){
        include('assets_template.php');
	} //fu

    //dynamically creates asset for - add more asset accounts
    function assets_form($addmore=0){
        $default=$_SESSION['assetsmore'];
        $default=$default + $addmore;

       echo "<table style='width: 100%;'>";

        echo "<tr><th>Institution Name</th><th>Type of Account</th><th>Account Number</th><th>Balance</th><th></th></tr>";
        echo   "<tr id='cloneme'> <td><input type='text' name='institutionname' id='institutionname' placeholder='Instituion Name'/></td>
                      <td><select name='account_types' data-mini='true' id='account_types'><option value=''>Select</option>
                      <option value='checking'>Checking</option>
                      <option value='savings'>Savings</option>
                      <option value='moneymarket'>Money Market</option>
                      <option value='CD'>CD</option>
                      <option value='MutualFund'>Mutual Fund</option>
                      <option value='Retirement'>Retirement</option>
                      <option value='Stock'>Stock</option>
                      <option value='CashDeposit'>Cash Deposit on Sales Contract</option>
                      <option value='Other'>Other</option>
                      </select></td>
                      <td><input type='text' name='accountnumber' id='accountnumber' placeholder='Account Number'/></td>
                      <td><input type='text' name='balance' id='balance' placeholder='Balance'/></td>

                </tr>";
         for ($i=0; $i<=$default; $i++){
           echo   "<tr id='".$i."'> <td><input type='text' name='institutionname".$i."' placeholder='Instituion Name'/></td>
                      <td><select name='account_types".$i."' data-mini='true'><option value=''>Select</option>
                      <option value='checking'>Checking</option>
                      <option value='savings'>Savings</option>
                      <option value='moneymarket'>Money Market</option>
                      <option value='CD'>CD</option>
                      <option value='MutualFund'>Mutual Fund</option>
                      <option value='Retirement'>Retirement</option>
                      <option value='Stock'>Stock</option>
                      <option value='CashDeposit'>Cash Deposit on Sales Contract</option>
                      <option value='Other'>Other</option>
                      </select></td>
                      <td><input type='text' name='accountnumber".$i."' placeholder='Account Number'/></td>
                      <td><input type='text' name='balance".$i."' id='balance".$i."' placeholder='Balance'/></td>

                </tr>";


        }// end of for


        echo "</div>";
        echo "<table id='addedRows' style='width: 100%;'>";
        echo "<tr style='visibility:hidden;'><th>Institution Name</th><th>Type of Account</th><th>Account Number</th><th>Balance</th></tr>";
        echo "</table>";

    }//fu

    /* dynamically creates schedule of real estated owned form fields*/
    function assets_ra_form($addmore=0){
        $default=$_SESSION['assetsmore'];
        $default=$default + $addmore;


        echo "<div class='assettable'>";
        for ($i=0; $i<=$default; $i++){
            echo "<div id='clone'>";
            echo "<span><strong>Property Information</strong><hr/></span>";
            echo "<span class='tablecell'><label for='asset_address".$i."'>Address:</label></span><span class='tablecell'><input type='text' name='asset_address".$i."' id='asset_address".$i."'/></span>";
            echo "<span class='tablecell'><label for='market_value".$i."'>Market Value:</label></span><span class='tablecell'><input type='text' name='market_value".$i."' id='market_value".$i."'/></span>";
            echo "<span class='tablecell'><label for='asset_city".$i."'>City:</label></span><span class='tablecell'><input type='text' name='asset_city".$i."' id='asset_city".$i."'/></span>";
            echo "<span class='tablecell'><label for='mortageamt".$i."'>Amt of Mortgage:</label></span><span class='tablecell'><input type='text' name='mortgageamt".$i."' id='mortgageamt".$i."' /></span>";
            echo "</div>";


        }//end of for


        echo "</div>";
        echo "<div class='assettable' id='addedRowsRA' style='width: 100%;'>";

       echo "</div>";



    }//fu

    /* creates drop down for account types on Assets Page*/
    function account_types(){
       echo "<select name='account_types' data-mini='true'>
       <option value=''>Select</option>
       <option value='checking'>Checking</option>
       <option value='savings'>Savings</option>
       </select>";

    }  //fu



} //end of class
?>
