<?php
require_once('account.class.php');
class applications extends account{
	var $app_id;
	var $app_status;
	var $app_date;
    var $fname;
    var $lname;



	function set_var($var, $value){
		//query database and set variable
		return $this->$var = $value;

	}    // fu


	function view_application($app_id, $username){
	    $link= $this->connectdb();

        $sql="SELECT application_id, app_date, app_status FROM applications WHERE application_id=?";
         $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
         mysqli_stmt_bind_param ($query, "s", $app_id);
         mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
         mysqli_stmt_store_result($query);

            if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found ";
                    //log error
            } else {

                    mysqli_stmt_bind_result($query, $application_id, $app_date, $app_status);
                    $x=0;

                    while (mysqli_stmt_fetch($query)) {
                       //echo "<div>".$application_id."</div><div>".$app_date."</div>".$app_status."</div><br/>";
                             $x++;
                              $this->set_var('app_status', $app_staus);
		                      $this->set_var('app_date', $app_date);

                    }
            }

	    include('templates/application_template.php');
	}  //fu
   

    function view_my_applications(){
       $link= $this->connectdb();

        $sql="SELECT application_id, app_date, app_status FROM applications WHERE applications.login_account_name=?";
        $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));

        mysqli_stmt_bind_param ($query, "s", addslashes($_SESSION['username']));
        mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
        mysqli_stmt_store_result($query);

        if( mysqli_stmt_num_rows($query) == 0){
            echo "No entries found ";
                    //log error
        } else {

            mysqli_stmt_bind_result($query, $application_id, $app_date, $app_status);
            $x=0;

            while (mysqli_stmt_fetch($query)) {
                $x++;
                echo "Application ".$x." here ".$app_date[$x]."&nbsp;".$application_id[$x]."<br/>";
                $this->set_var('app_status', $app_staus);
		        $this->set_var('app_date', $app_date);
                include('templates/application_template.php');
            }
        }



    } //fu


    function view_all_applications(){

	    $link= $this->connectdb();

         $sql="SELECT application_id, app_date, app_status, borrowers.borrower_fname, borrowers.borrower_lname FROM applications, borrowers where applications.application_id = borrowers.app_id AND borrowers.coborrower='n' ORDER BY app_date DESC, borrowers.borrower_lname";
         $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
         mysqli_stmt_bind_param ($query, "s", $app_id);
         mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
         mysqli_stmt_store_result($query);

            if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found ";
                    //log error
            } else {

                    mysqli_stmt_bind_result($query, $application_id, $app_date, $app_status, $fname, $lname);
                    $x=0;

                    echo "<h4>Search for<hr/>";
                    //echo "<form><input type='search' name='search' id=\"search\"/></form>";

                    //echo "<span style='clear: both; display:block; width: 100%;'></span>";
                    echo "<ul data-role=\"listview\"  data-filter=\"true\" data-filter-reveal=\"false\" >";         //data-autodividers=\"true\"
                    while (mysqli_stmt_fetch($query)) {

                              $x++;
                              $this->set_var('app_status', $app_status);
		                      $this->set_var('app_date', $app_date);
                              $this->set_var('app_id', $application_id);
                              $this->set_var('fname', $fname);
                              $this->set_var('lname', $lname);
                              include('templates/applications.php');
                    }
                    echo "</ul>";

            }


	}
    function validate_address(){
   
    }
    function add_application($status){
         $link = $this->connectdb();
         $ip=$_SERVER['REMOTE_ADDR'];
         //log invalid attempts by ip address and supplied username
         $sql="INSERT into applications (app_date, app_status, session_id, origination_ip) VALUES(NOW(),?,?,?)";
         $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
         mysqli_stmt_bind_param ($query, "sss", $status,session_id(),$ip);
         mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
         return $query->insert_id;


    }


}//end of class
