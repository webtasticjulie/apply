<?php session_start("checklist");
//steps.class.php
require_once ('applications.class.php');

class steps extends applications{
var $step_id;
var $step_question;
var $category;
var $step_weight;
var $step_flags;
var $element_count;

		/*query steps from database*/
        function get_steps(){

           $link = $this->connectdb();
           $query = mysqli_prepare($link,"SELECT DISTINCT step_id, step_question, step_category, step_weight, step_flags FROM steps  ORDER BY step_weight")
           or die("Error: ". mysqli_error($link));

          // mysqli_stmt_bind_param ($query, "s", $option);
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);
           if( mysqli_stmt_num_rows($query) == 0){
                echo "No entries found";
           } else {

                // bind variables to prepared statement
                mysqli_stmt_bind_result($query,$step_id,$step_question, $step_category, $step_weight, $step_flags);
                while (mysqli_stmt_fetch($query)) {
                    $this->step_id=$step_id;
                    $this->step_question=$step_question;
                    $this->category=$step_category;
                    $this->step_weight = $step_weight;
                    $this->step_flags = $step_flags;
                    $this->element_count = $this->count_elements($step_id);  
                    include('templates/steps.php');
                }
          }
          mysqli_stmt_close($query);
          mysqli_close($link);


        } //fu

        function get_nav(){
            $link = $this->connectdb();
           $query = mysqli_prepare($link,"SELECT step_id, step_question, step_category, step_weight FROM steps ORDER BY step_weight")
           or die("Error: ". mysqli_error($link));

           //mysqli_stmt_bind_param ($query, "s", $active);
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);
           if( mysqli_stmt_num_rows($query) == 0){
                echo "No entries found";
           } else {

                // bind variables to prepared statement
                mysqli_stmt_bind_result($query,$step_id,$step_question, $step_category, $step_weight);
                while (mysqli_stmt_fetch($query)) {
                    $this->step_id=$step_id;
                    $this->step_question=$step_question;
                    $this->category=$step_category;
                    $this->step_weidth = $step_weight;
                    //include('templates/steps.php');
                    echo "<li><a href='#step".$step_id."'><span>".$step_category."</span></a></li>";

                }
          }
          mysqli_stmt_close($query);
          mysqli_close($link);
        }   //fu


        function get_all_steps(){

           $link = $this->connectdb();
           $query = mysqli_prepare($link,"SELECT step_id, step_question, step_flags FROM steps ORDER BY step_flags, step_weight")
           or die("Error: ". mysqli_error($link));

           //mysqli_stmt_bind_param ($query, "s", $active);
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);
           if( mysqli_stmt_num_rows($query) == 0){
                echo "No entries found";
           } else {

                // bind variables to prepared statement
                mysqli_stmt_bind_result($query,$step_id,$step_question, $step_flags);
                $x=0;
                echo "<ul id='allsteps'>";

                while (mysqli_stmt_fetch($query)) {

                    $this->step_id=$step_id;
                    $this->step_question=$step_question;
                    $this->count_elements($step_id);
                    echo "<li class='ui-state-default'><span class='ui-icon ui-icon-arrowthick-2-n-s'></span>".$this->step_question." ".$this->element_count."</li>";
                    $x++;
                }
                echo "</ul>";


            }
            mysqli_stmt_close($query);
            mysqli_close($link);


        } //fu
        function count_elements($step){
             $link = $this->connectdb();
             $query = mysqli_prepare($link,"SELECT count(step_elements.element_id) as element_count FROM step_form_elements, step_elements WHERE step_elements.element_id = step_form_elements.element_id AND step_elements.step_id=?") or die("Error: ". mysqli_error($link));

               mysqli_stmt_bind_param ($query, "s", $step);
               mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
               mysqli_stmt_store_result($query);
               if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found";
               } else {

                    // bind variables to prepared statement
                    mysqli_stmt_bind_result($query,$element_count);
                    $x=0;
                    // fetch values

                    while (mysqli_stmt_fetch($query)) {
                        $this->element_count = $element_count;
                        echo "Here".$element_count;
                        return $element_count;
                    }


                }
                mysqli_stmt_close($query);
                mysqli_close($link);

        }
        function get_elements($step){

               $link = $this->connectdb();
               $query = mysqli_prepare($link,"SELECT element_html FROM step_form_elements, step_elements WHERE step_elements.element_id = step_form_elements.element_id AND step_elements.step_id=? ORDER BY weight")
               or die("Error: ". mysqli_error($link));

               mysqli_stmt_bind_param ($query, "s", $step);
               mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
               mysqli_stmt_store_result($query);
               if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found";
               } else {

                    // bind variables to prepared statement
                    mysqli_stmt_bind_result($query,$element_html);
                    $x=0;
                    // fetch values

                    while (mysqli_stmt_fetch($query)) {
                        echo eval($element_html);
                        $x++;
                    }


                }
                mysqli_stmt_close($query);
                mysqli_close($link);


        }




}//end of class


?>


