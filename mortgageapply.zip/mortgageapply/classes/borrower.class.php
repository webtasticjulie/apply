<?php
require_once('applications.class.php');
class borrower extends applications{
     var $fname;
	 var $lname;
	 var $mi;
     var $street;
	 var $city;
     var $state;
     var $zip;
	 var $mobile;
	 var $home;
     var $email;
     var $years_current;
     var $dob;


	function view_borrower(){
        include('templates/borrower_template.php');
	}
    function create_borrower($fname, $lname, $mi, $street, $zip, $city, $state, $mobile, $home, $email, $dob){
        $this->set_var('fname', $fname);
        $this->set_var('lname', $lname);
        $this->set_var('mi', $mi);
        $this->set_var('zip', $zip);
        $this->set_var('city', $city);
        $this->set_var('state', $state);
        $this->set_var('mobile', $mobile);
        $this->set_var('home', $home);
        $this->set_var('street', $street);
        $this->set_var('email', $email);
        $this->set_var('dob', $dob);
        $this->set_var('years_current', '8');

    }
    function add_borrower($fname, $lname, $mi, $street, $zip, $city, $state, $mobile, $home, $email, $dob,$coborrower, $app_id){

        $link = $this->connectdb();
         //trimming to max allowed character length by database - also adding slashes for security measures
        $fname = addslashes($this->trim_length(100, $fname));
        $lname = addslashes($this->trim_length(100, $lname));
        $mi = addslashes($this->trim_length(2, $mi));
        $street = addslashes($this->trim_length(100, $street));
        $city = addslashes($this->trim_length(100, $city));
        $state = addslashes($this->trim_length(50, $state));
        $zip = addslashes($this->trim_length(100, $zip));
        $dob = addslashes($this->trim_length(100, $dob));
        $mobile = addslashes($this->trim_length(30, $mobile));
        $home = addslashes($this->trim_length(30, $home));
        $email = addslashes($this->trim_length(100, $email));
        $allowed_values=array('y','n');
        in_array($coborrower, $allowed_values)? $coborrower=$coborrower:$coborrower='n';    //if not in allowed values, then set to n by default

        $query = mysqli_prepare($link,"INSERT INTO borrowers (borrower_fname, borrower_mi, borrower_lname, borrower_email, borrower_street, borrower_city, borrower_state, borrower_zip, borrower_dob, borrower_mobile, borrower_home, coborrower, app_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);") or die("Error: ". mysqli_error($link));
        mysqli_stmt_bind_param ($query, "sssssssssssss", $fname, $mi, $lname, $email, $street, $city, $state, $zip,$dob, $mobile, $home,$coborrower,$app_id);
        mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
        mysqli_close($link);

    }

}
?>
