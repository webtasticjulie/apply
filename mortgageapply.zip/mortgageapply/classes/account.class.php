<?php session_start("checklist");
//account.class.php
class account {
        var $username;
        function login(){

            $link=$this->connectdb();
            $username = addslashes($_POST['username']);
            $supp_password = $_POST['password'];
            $salt="Myrandomsalt";
            $supp_secret = crypt($supp_password, $salt);  //hash password to compare in database
            $query = mysqli_prepare($link,"SELECT login_account_password FROM login_account WHERE login_account_name=?") or die("Error: ". mysqli_error($link));
            mysqli_stmt_bind_param ($query, "s", $username);
            mysqli_stmt_execute($query) or die("Error. Could not select from the table.".mysqli_error($link));
            mysqli_stmt_store_result($query);
            if( mysqli_stmt_num_rows($query) == 0){
                 echo "<div style='display:block; background-color: red; font-weight: bold; padding: 10px;'>Invalid Login Credentials</div>";
                 $this->log_invalid($username, 'l');
            } else {

                mysqli_stmt_bind_result($query,$password);


                while (mysqli_stmt_fetch($query)) {
                   //check if the hashed password matches the provided password
                    if ($supp_secret == $password){  //if it matches log user in  and set session variables then redirect to landingpage
                        $_SESSION['username'] = $username;
						$this->username=$username;
                        $_SESSION['loggedin'] = '1';   // set logged into 1 (true logged in)
                        $this->track_logins();
                        //echo $_SESSION['loggedin']."you're logged in.";
                        ?>
                        <script type="text/javascript">
                        window.location.href="index.php";

                        </script>
                        <?php

                    }else{   //wrong password
                        echo "<strong>Uh oh! Something didn't work. Invalid Credentials</strong>";
                        $_SESSION['loggedin']='0';
                        //add invalid counter
                    }  //end if

                 } //end while
            } //end if else


        }   //fu

		/*save all post data to the session*/
		function save_session(){

          foreach($_POST as $key=>$value){    //iterate through post values and save to session
                 $_SESSION[$key]=$value;
                 //echo "Saving ".$key." as ".$value."<br/>";
          }

        }  //fu

        

		/*logout of session*/
        function logout(){
           session_destroy();
        }  //fu

        function track_logins(){
            $link=$this->connectdb();
            $ip=$_SERVER['REMOTE_ADDR'];
            $query = mysqli_prepare($link,"INSERT INTO login_audit (login_username, login_date, login_ip) VALUES(?, NOW(), ? )")
            or die("Error: ". mysqli_error($link));
            mysqli_stmt_bind_param ($query, "ss", $_SESSION['username'], $ip);
            mysqli_stmt_execute($query) or die("Error. Could not insert into the table.".mysqli_error($link));
            mysqli_stmt_close($query);
            mysqli_close($link);
        }  //fu

		/*register the user in the database*/
        function register_user($first_login, $first_password, $confirm_password,$first_name, $email){

            $link=$this->connectdb();
            $valid_pass = false;

            //check if the email account exists already
            $exists = $this->check_exists('login_account', 'login_account_email', $email);

            //check password and confirm password match  and that it meets security requirements
            $valid_pass = $this->validate_password($first_password, $confirm_password);
            if ($valid_pass){

                $salt="Myrandomsalt";
                // Hash the password with the salt
                $secret = crypt($first_password, $salt);
            }
            if ($exists == 0){

               //add user to login account
                $query = mysqli_prepare($link,"INSERT INTO login_account (login_account_name, login_account_email, login_account_password, login_account_date) VALUES(?, ?, ?, NOW() )")
                or die("Error: ". mysqli_error($link));
                mysqli_stmt_bind_param ($query, "sss", $first_login, $email, $secret);
                mysqli_stmt_execute($query) or die("Error. Could not insert into the table.".mysqli_error($link));
               //now add security questions
               $user_id = $link->insert_id;
               $this->add_security_questions($user_id);
               echo "<span style=\"padding: 5px;\">Your account was created successfully</span>";
           }else{
               echo "<span style=\"padding: 5px; display:block; background-color: red; font-weight: bold;\">An account already exists with this email address.</span>";
           }
           mysqli_stmt_close($query);
           mysqli_close($link);


        }   //fu

		/*query set of security questions from database - dynamically generate select options*/
        function get_questions($attr, $return_array=false, $active=1){

               $link = $this->connectdb();
               $query = mysqli_prepare($link,"SELECT question_id, question FROM questions where active = ?")
               or die("Error: ". mysqli_error($link));

               mysqli_stmt_bind_param ($query, "s", $active);
               mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
               mysqli_stmt_store_result($query);
               if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found";
               } else {

                    // bind variables to prepared statement
                    mysqli_stmt_bind_result($query,$question_id,$question);
                    $x=0;
                    // fetch values
                    $questions_array=array();
                    while (mysqli_stmt_fetch($query)) {
                        $questions_array[]=$question_id;
                        if ($return_array===false){
                            echo "<option  id='".$attr.$x."' value='".$question_id."'>".$question."</option>";
                        }
                       $x++;
                    }
                    if ($return_array===true){
                        return $questions_array;
                    }

                }
                mysqli_stmt_close($query);
                mysqli_close($link);
        }

		/*add users selected security questions and answers to database*/
        function add_security_questions($user_id){
            $link = $this->connectdb();
			//create questions array with question as key and answer as value
            $questions[$_POST['securityquestions1']]=addslashes($_POST['securityquestion_answer1']);
            $questions[$_POST['securityquestions2']]=addslashes($_POST['securityquestion_answer2']);
            $questions[$_POST['securityquestions3']]=addslashes($_POST['securityquestion_answer3']);

			//iterate through array - if not null add to database
            foreach($questions as $question=>$answer){
                //make sure that the question id submitted is a valid question id in the database and not altered or tampered with
                $valid_questions = $this->get_questions('',true, 1);

                if (in_array($question, $valid_questions)){

                    if ((!is_null($question)) && ( !is_null($answer))){
                        $answer = addslashes($this->trim_length(100, $answer));    //trimming to 100 characters allowed by database - also adding slashes for security measures
                        $query = mysqli_prepare($link,"INSERT INTO recovery_questions (question_id, user_id, answer) VALUES (?,?,?);") or die("Error: ". mysqli_error($link));
                        mysqli_stmt_bind_param ($query, "sss", $question, $user_id, $answer);
                        mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
                    }
                }
            }
            mysqli_close($link);

        } //fu

        /* returns trimmed value to a maximum length */
        function trim_length($max_length, $s){

              if (strlen($s) > $max_length)
                {
                    $offset = ($max_length - 3) - strlen($s);
                    $s = trim(substr($s, 0, strrpos($s, ' ', $offset)));

                }
                return trim($s);

        }

        /* validate that the passwords match - future add complexity check*/
        function validate_password($first_password, $confirm_password){
            if ($first_password != $confirm_password){
               die("Your passwords do not match. Please verify that the passwords match");
            }else{      //TODO: add length variation specifications
                return true;
            }

        } //fu

		/* check if a value exists in a specific table and field*/
        function check_exists($table, $field, $value){
           $link=$this->connectdb();
           if ($result = $link->query("SELECT ".$field." FROM ".$table." WHERE ".$field." = '".$value."'")) {
                /* determine number of rows result set */
                $row_cnt = $result->num_rows;
                return $row_cnt;
           }else{
               return 0;
           }
           /* close result set */
           $result->close();
           mysqli_close($link);
        }  //fu




        /* connect to database*/
        function connectdb(){
              //include global variables to reduce security vulnerabilities
              require('/var/secure/apply/secure.php');
              $conn = new mysqli($host, $username, $pass, $db);
              if (mysqli_connect_errno($conn)){
                  echo 'Cannot connect to database: ' . mysqli_connect_error();
              }else{

                 return $conn;
              }

        } //fu

        /* queries the username from the email address on file*/
        function recover_username($email){

            $link = $this->connectdb();
            $sql = "SELECT login_account_name FROM login_account WHERE login_account_email = ?";
            $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
            mysqli_stmt_bind_param ($query, "s", $email);
            mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
            mysqli_stmt_store_result($query);
               if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found with that email address";
               } else {

                    // bind variables to prepared statement
                    mysqli_stmt_bind_result($query,$username);

                    // fetch values
                    while (mysqli_stmt_fetch($query)) {
                       $msg= "Your username is:".$username;
                       echo "<strong>For your security, your username has been emailed to the email address on file.";
                       //mail('julie.redfoot@homestarfc.com', 'Your requested information', $msg);  //commented out for now until email is fixed on server

                    }
                }

                mysqli_stmt_close($query);
                mysqli_close($link);
        }  //fu

        //selects the users specific security questions - displays security questions to user when they are attempting to recover their information
        function prompt_security_questions($username){
            $link = $this->connectdb();
            $sql = "SELECT questions.question From questions, recovery_questions, login_account WHERE login_account.login_account_id = recovery_questions.user_id AND recovery_questions.question_id = questions.question_id AND login_account.login_account_name=?";
            $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
            mysqli_stmt_bind_param ($query, "s", $username);
            mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
            mysqli_stmt_store_result($query);
            echo "<form name='securequestions' method='post' action='index.php'>";
            echo "<input type='hidden' name='formname' value='securityanswers'/>";
            if( mysqli_stmt_num_rows($query) == 0){
                    echo "No entries found with that username";
            } else {

                    // bind variables to prepared statement
                    mysqli_stmt_bind_result($query,$question);
                      $x=0;
                    // fetch values
                    while (mysqli_stmt_fetch($query)) {
                      echo "<label for='answers".$x."'>".$question."</label>";
                      echo "<input type='hidden' name='questions".$x."' value='".$question."'/>";
                      echo "<input type='hidden' name='username' value='".$username."'/>";
                      echo "<input type='text' name='answers".$x."' value=''/>";
                      $x++;

                    }
            }
            echo "<input type='submit' value='Submit'/>";
            echo "</form>";
            mysqli_stmt_close($query);
            mysqli_close($link);

        }  //fu

        //compare the answers to the save security questions when account was created to provided answers to recover password
        function compare_answers($answer, $question, $username){
            $link = $this->connectdb();
            $sql = "SELECT recovery_questions.answer From questions, recovery_questions, login_account WHERE login_account.login_account_id = recovery_questions.user_id AND recovery_questions.question_id = questions.question_id AND login_account.login_account_name=? AND questions.question=?";
            $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
            mysqli_stmt_bind_param ($query, "ss", $username, $question);
            mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
            mysqli_stmt_store_result($query);
            if( mysqli_stmt_num_rows($query) == 0){
                    echo "Invalid Response - question not in the database".$question."<br/>";
                    return "Invalid";
            } else {
                    mysqli_stmt_bind_result($query,$saved_answer);
                    while (mysqli_stmt_fetch($query)) {
                       if (strtolower($answer) == strtolower($saved_answer)){
                           //echo "<div style=\"background-color:green;display:block;\">Matched!</div>";
                           return "Valid";
                       }
                    } //end of while
            }
            mysqli_stmt_close($query);
            mysqli_close($link);
        }//fu

        // log invalid password recovery attempts
        function log_invalid($username, $type='l'){
          $link = $this->connectdb();
          $ip=$_SERVER['REMOTE_ADDR'];
          //log invalid attempts by ip address and supplied username
          $sql="INSERT into invalid (invalid_ip, invalid_date, invalid_username, type) VALUES(?,NOW(),?,?)";
          $query = mysqli_prepare($link,$sql) or die("Error: ". mysqli_error($link));
          mysqli_stmt_bind_param ($query, "sss", $ip, $username, $type);
          mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
          mysqli_stmt_close($query);
          mysqli_close($link);

        } //fu


        //returns the count of invalid logins within the last hour. If more than 3, it locks the user out from that attempting to login again from the same IP address
        function get_invalid($username, $type){
           $link = $this->connectdb();
           $ip = $_SERVER['REMOTE_ADDR'];
           //get the number of invalid attempts by IP address and username within the last hour
           $sql = "SELECT count(invalid_id) as invalid_count FROM invalid WHERE invalid_ip=? AND invalid_username=? AND invalid_date >= (NOW() - INTERVAL 1 HOUR) AND type=?";
           $query = mysqli_prepare($link, $sql) or die("Error:".mysqli_error(link));
           mysqli_stmt_bind_param($query, "sss", $ip, $username, $type);
           mysqli_stmt_execute($query) or die("Error. Could not query the table.".mysqli_error($link));
           mysqli_stmt_store_result($query);
           mysqli_stmt_bind_result($query,$invalid_count);

           while (mysqli_stmt_fetch($query)) {
               if ($invalid_count>=3){
                    echo "<div style=\"background-color:red; display:block; font-weight: bold; text-align: center;\"><h2>STOP! Too many attempts have been logged. You have been locked out.</h2></div>";
                    echo "<p>We care about your security. You have been locked out to protect your information. If you would like immediate assistance, please call ###-###-####.</p>";
                    exit;
               }else{
                    return $invalid_count;
               }

            }  //end of while
            mysqli_stmt_close($query);
            mysqli_close($link);
        } //fu


        function check_validity(){
            $invalid_count=$this->get_invalid($_POST["username"]);


            if ($invalid_count<3){
                $valid1=$this->compare_answers($_POST["answers0"], $_POST["questions0"], $_POST["username"]);
                $valid2=$this->compare_answers($_POST["answers1"], $_POST["questions1"], $_POST["username"]);
                $valid3=$this->compare_answers($_POST["answers2"], $_POST["questions2"], $_POST["username"]);

                if (($valid1 == "Valid") && ($valid2 == "Valid") && ($valid3 == "Valid")){
                    echo "<div style=\"background-color:green;display:block;\">Valid Responses</div><br/>";
                   //TODO:  add function to send password reset to user
                }else{
                    echo "<div style=\"background-color:red;display:block;\">Invalid Response. Please try again. You will be locked out after 3 invalid attempts.</div>";
                   //log invalid attempts
                   $this->log_invalid($_POST["username"]);
                }
            }else{
                echo "Too Many invalid attempts. You've been locked out.";
                exit;
            }
            exit;

        }//fu

        function check_security(){
            $invalid_count=$this->get_invalid($_POST['accountusername'], 's');
            if ($invalid_count<3){
                $this->prompt_security_questions($_POST['accountusername']);
            }else{
                echo "<strong>We at Homestar care about the security of your information. You have had too many invalid attempts to recover your information. You have been locked out temporarily.</strong>";
                exit;
            }
            exit;

        }//fu
        function check_loggedin(){
            if ($_SESSION['loggedin']=='1'){
                return true;
            }else{
               echo "<div style=\"margin-right: auto; margin-left: auto; width: 85%; padding: 1.5em;\"><strong>Unauthorized. Your session may have timed out.  Please <a href=\"index.php\">log in</a> to view this page.</strong></div>";
               exit;
            }
        }



}//end of class



?>
