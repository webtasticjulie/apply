<?php
if (!isset($_SESSION)) {
  session_start("checklist");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
	<link rel="shortcut icon" href="favicon.png" type="image/x-icon"/>
    <link rel="stylesheet" type="text/css" href="/var/www/homestar/development/applyguided/www/css/index.css">
    <title>
      Homestar Financial
    </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src= "//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
    <script type="text/javascript" src="js/progressbar.js"></script>
    <script type="text/javascript" src="js/addmore.js"></script>
    <script type="text/javascript" src="js/addmorejq.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <link rel="stylesheet" href="/var/www/homestar/development/applyguided/www/css/custom.css">
   </head>
  <body>
<?php
if (!isset($_SERVER['PHP_AUTH_USER'])) {
    header('WWW-Authenticate: Basic realm="My Realm"');
    header('HTTP/1.0 401 Unauthorized');
    echo 'Text to send if user hits Cancel button';
    exit;
} else {
    echo "<p>Hello {$_SERVER['PHP_AUTH_USER']}.</p>";
    //echo "<p>You entered {$_SERVER['PHP_AUTH_PW']} as your password.</p>";
    if (trim($_SERVER['PHP_AUTH_USER'])=="webtasticjulie"){
        //echo "allowed";
  ?>

  <?php
  if ($_POST){
      print_r($_POST);
      require('/var/secure/apply/secure.php');
      $link = mysql_connect($host, $username, $pass);
      mysql_select_db("mortgage_checklist");
        if (!$link) {
            die('Could not connect: ' . mysql_error());
        }
        //echo 'Connected successfully';
      $sql="SELECT * FROM borrowers WHERE borrower_lname LIKE '%".$_POST['lname']."%'";
      $result=mysql_query($sql,$link);
      echo "<h2>Results</h2>";
      while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
        printf("<br/>ID: %s  Name: %s Last Name: %s", $row["borrower_id"], $row["borrower_fname"], $row["borrower_lname"])."";
      }
      exit;
  }
  ?>
 <div data-role="page" id="step1">
        <div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
        </div>
         <div data-role="content">

         <div class="stepquestion">
         <span class="stepquestionheader"><h3><?php echo "Personal"; ?></h3></span>
         <span class="question">
          <h3>1. What's your name?</h3>
          <form name="step1" id="form_step1" method="POST" action="" >
            <input type="hidden" name="formname" value="step1"/>
            <label for="fname">First Name:<input type="text" name="fname"/></label>
            <label for="lname">Last Name:<input type="text" name="lname"/></label>

            <br/><br/>

           <hr/>

            <span class="bottombuttons">
                <span class="half">
                    <?php if (1>1){
                        echo "<input type='button' name='back' value='Back'  data-mini='true' data-theme='c' data-icon='carat-l' data-iconshadow='true' onclick='location.href=\"#step".($this->step_weight - 1).$this->step_flags."\";'/>";
                    }  ?>
                </span>
                <span class="half">
                    <input type="submit" data-mini="true" data-theme="c" data-icon="carat-r" data-iconpos="right" data-iconshadow="true" name="step1" value="Next">
                </span>
            </span>

          </form>
           </span>
           </div>


         </div>
          <div data-role="footer" style="text-align: center; width: 100%; position: absolute; bottom: 0px;"><br/>&copy;Homestar Financial 2016<br/><br/></div>
 </div>












  <?php





    }else{
        echo "STOP! You are not allowed in";
    }
}


?>
