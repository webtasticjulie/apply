<div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
</div>
        <div role="main" class="ui-content">
        <?php

        require_once('classes/account.class.php');
        $account = new account;
        if ($_GET["lo"]==true){
            include('logout.php');
        }
	    if (($_POST['lostusername']) || ($_POST['recoverusername']) || ($_POST['lostpassword']) || ($_POST['recoverpassword'])  || ($_POST['lostoption']=="lostusername") || ($_POST['lostoption']=="lostpassword") || ($_POST['lostoption']=="lostboth")){

	        include('lost.php');
        }elseif ($_POST['formname']=="summary"){
            ?>
            <script type="text/javascript">
               changePages('#complete');
            </script>

        <?php

        }else{
             //$account->save_session();
            if (strpos($_POST['formname'], 'step') !== false) {  //contains the word step
                $int = filter_var($_POST['formname'], FILTER_SANITIZE_NUMBER_INT) + 1;  //increment previous step by one to advance to next step
                //$account->save_session();  //save the coborroweropt variable in a session variable used to redirect to correct step path   current values are set to c or a coborrower or alone
                //$account->save_draft($_POST['formname']);


            ?>
            <script type="text/javascript">
                var step= "#step" + "<?php echo $int;?>"+ "<?php echo $_SESSION["coborroweropt"];?>";
               // alert(step);
                if( $(step).length )         // use this if you are using id to check
                {

                    // it exists
                    changePages(step);
                }else{
                    //assume at end
                    changePages('#summary');
                }
            </script>
            <?php
            }else if ($_SESSION['loggedin']=='1'){
                include('landingpage.php');
            }else{

                ?>
            	<h4>Please login or create an account</h4>
                <p>In order to begin the application process, please login or create an account.</p>
                <div id="applynow" class="applynow">
                    <?php
                    if ($_POST['loginaccount']=="loginaccount"){
                       	$account -> login();
                    }
                    if ($_POST['createaccount']=="createaccount"){
                       	$account ->  register_user($_POST['username'], $_POST['password'], $_POST['confirmpassword'],$_POST['firstname'], $_POST['email']);
                    }
                    ?>
                    <div class="leftcol"></div>
                    <div class="rightcol">
                        <?php include('login.php');?>
                    </div>
                </div>

        <?php
            }

        } ?>
        <!--<script type="text/javascript" src="cordova.js"></script> -->
        <script type="text/javascript" src="js/index.js"></script>
      </div>

      <div data-role="footer">
      </div><!-- /footer -->