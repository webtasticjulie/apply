<?php

      echo "<li>";
      echo "<div data-role=\"collapsible\" data-collapsed=\"true\"><h1>".$this->lname.",".$this->fname." Submitted on".date('M-d-Y h:i a',strtotime($this->app_date))."</h1>";
        echo "<div data-role=\"collapsible\" data-collapsed=\"false\"><h1>Borrower Info</h1></div>";

      echo "</div>";
      echo "</li>";


?>
