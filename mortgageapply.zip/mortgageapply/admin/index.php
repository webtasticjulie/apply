<?php
if (!isset($_SESSION)) {
  session_start("checklist");
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="format-detection" content="telephone=no">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="viewport" content="user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width">
	<link rel="shortcut icon" href="img/favicon.png" type="image/x-icon"/>
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <title>
      Homestar Financial
    </title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <script src= "//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>

    <script type="text/javascript">



    $(function() {
        $( "#allsteps" ).sortable();
        $( "#allsteps" ).disableSelection();
    });



    </script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
    <link rel="stylesheet" href="../css/custom.css">
    <link rel="stylesheet" href="../css/steps.css">
   </head>
  <body>

    <div data-role="page" id="adminhome">
     <div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar Admin
        </h1>
    </div>
    <h3>Admin Home</h3>
    <div data-role="content">
<h3><strong>Select From the Following:</strong></h3>
    <ul data-role="listview" class="tasklist">
      <li data-icon="search"><a href="#manageapps">View All Applications</a></li>

      <li data-icon="minus"><a href="#managesteps">View Steps</a></li>
     </ul>

</div>
<div data-role="footer" style="text-align: center; width: 100%; position: absolute; bottom: 0px;"><br/>&copy;Homestar Financial 2016<br/><br/></div>
    </div>



    <!--manage steps sortable-->
    <div data-role="page" id="managesteps">
         <div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
        </div>
          <div data-role="content">
          <h3>Manage Steps</h3>
          <?php require_once('../classes/steps.class.php');

            $steps=new steps;
            $steps->get_all_steps();

          ?>
          </div>
          <div data-role="footer"></div>
    </div>

     <!--manage steps sortable-->
    <div data-role="page" id="manageapps">
         <div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
        </div>
          <div data-role="content">

          <?php require_once('../classes/applications.class.php');

            $application = new applications;
            $application->view_all_applications();

          ?>
          </div>
          <div data-role="footer"></div>
    </div>










    <div data-role="footer">
    </div>
  </body>
</html>
