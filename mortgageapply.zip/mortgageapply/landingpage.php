
       <div data-role="header">
        <h1>
         Welcome <?php echo $_SESSION['username'];?>
        </h1>

      </div>
      <div class="borrowertab">
      <br/><br/>
     <strong> What would you like to do?</strong><br/>
      <ul style="list-style-type:none;">

      <li><a href="#step0" data-transition="slide" data-role="button" data-icon="plus" data-mini="true">Fill out an Application</a></li>

      <li><a href="#mytasks" data-transition="slide" data-role="button" data-icon="check" data-mini="true">Review Items Needed</a></li>
	  <li><a href="#contact" data-transition="slide" data-role="button" data-icon="arrow-r" data-mini="true">Contact Us</a></li>
      <li><a href="?lo=true" data-role="button" data-icon="arrow-r" data-mini="true">Log out</a></li>
      </ul>



        </div>

