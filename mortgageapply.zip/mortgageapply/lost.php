<div data-role="header">
    <h1>
     Recover Username/Password
    </h1>
</div>
<div class="borrowertab">
<?php

if ($_POST['recoverusername']){
    $account->recover_username($_POST['accountemail']);
    exit;
}
if ($_POST['recoverpassword']){
     $account->check_security();
}
if ($_POST['formname']=='securityanswers'){

    $account->check_validity();
}

if ($_POST['lostoption'] == 'lostusername'){
    include('recoverun.html');
}elseif ($_POST['lostoption'] == 'lostpassword'){
    include('recoverpw.html');
}else{
    include('forgotcreds.html');
}
?>
</div>