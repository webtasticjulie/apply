<div data-role="header">
    <h1>
      Assets
    </h1>
</div>

<div class="progressbar">
    <div></div>
</div>

<div class="borrowertab">
    <?php include('tabs.html');?>
    <div style="clear: left;"></div>

    <form name="assets" action="index.php" method="post">
      <div style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
          <p>Are you working with a Financial Advisor?&nbsp; &nbsp;
              <select name="financialadvisor" id="financialadvisor" data-role="slider" data-mini="true">
                  <option value="yes">Yes</option>
                  <option value="no">No</option>
              </select>
          </p>
      </div>
    <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
        <legend>Assets and Income</legend>

        <label for="gross">Monthly Income: (Gross) <input type="number" name="gross"  id="gross"  data-mini="true" required></label>
        <label>Sources of Income:</label>
        <label for="selfemployed"><input type="checkbox" name="sources" id="selfemployed" value="Self Employed"  data-mini="true"/>Self Employed</label>
        <label for="commisions"><input type="checkbox" name="sources" id="commissions" value="Commissions"  data-mini="true"/>Commissions</label>
        <label for="salary"><input type="checkbox" name="sources" id="salary" value="Salary"  data-mini="true"/>Salary</label>
        <label for="hourly"><input type="checkbox" name="sources" value="Hourly" data-mini="true"/>Hourly</label>
        <label for="other"><input type="checkbox" name="sources" value="Other"  data-mini="true"/>Other</label>
    </fieldset>
    <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
        <legend>Asset Accounts</legend>
         <?php include_once ('classes/assets.class.php');
         $assets = new assets;
         $assets->assets_form(1);
         ?>
         <span id="actionbuttons" style="display: inline; width: 100%;">
         <!-- onclick="addMoreRows(this.form);" -->
         <a href='#' id="addmore" data-role="button" data-icon="plus" style="width: 70px; float: left;" data-mini="true"> Add More </a>
         <a href="javascript:void(0);" id="removerows" data-role="button" data-icon="minus" style="width: 70px; float: left;" data-mini="true">Remove</a>  <!--onclick="removeRow(this);"-->

         </span>
    </fieldset>

    <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
        <legend>Schedule of Real Estate Owned</legend>
        <div class="propertyinformation">
        <?php
        $assets->assets_ra_form(0);
        ?>
        <span id="actionbuttons" style="display: inline; width: 100%;">
        <a href='#' id='addmorera' data-role="button" data-icon="plus"  style="width: 70px; float: left;" data-mini="true" onclick="addMoreRaRows();"> Add More </a>
        <a href="javascript:void(0);" data-role="button" data-icon="minus" style="width: 70px; float: left;" data-mini="true" onclick="removeRARow();">Remove</a>
        </span>
        </div>
    </fieldset>

    <input type="hidden" name="formname" value="assets"/>
    <input type="submit" name="assets" value="Next"/>
    </form>


</div>