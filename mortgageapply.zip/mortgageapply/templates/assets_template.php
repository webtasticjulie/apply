<div class="summaryinfo">
    <div data-role="collapsible" data-collapsed="false">
       <h3>Assets Info</h3>
       <a href="index.php#assets" data-role="button" data-icon="grid" data-mini="true" style="width:4em; float: right;">Edit</a>

       <span class="label">Asset Account: </span>  <br>



    </div>

</div>