template files are included in the view of the summary page
