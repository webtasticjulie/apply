<div class="summaryinfo">
    <div data-role="collapsible" data-collapsed="false">
       <h3>Borrower Info</h3>
       <a href="index.php#applypage" data-role="button" data-icon="grid" data-mini="true" style="width:4em; float: right;">Edit</a>

       <span class="label">Borrower Name: </span> <?php echo $this->fname." ".$this->mi." ".$this->lname; ?> <br>
       <span class="label">Email:</span> <?php echo $this->email;?> <br>
       <span class="label">Home Phone:</span> <?php echo $this->home;?><br>
       <span class="label">Mobile Phone:</span><?php echo $this->mobile;?><br>
       <span class="label">Street Address:</span><?php echo $this->street;?><br>
       <span class="label">City:</span><?php echo $this->city;?><br>
       <span class="label">State:</span><?php echo $this->state;?><br>
       <span class="label">Zip:</span><?php echo $this->zip;?><br>
       <span class="label">DOB:</span><?php echo $this->dob;?><br>
       <span class="label">Years at Current Location:</span><?php echo $this->yearscurrent;?><br>


    </div>

</div>