
 <div data-role="page" id="step<?php echo $this->step_weight; echo $this->step_flags;?>">
        <div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
        </div>
         <div data-role="content">
          <aside>
           <div id='cssmenu'>
<ul>
   <!--<li class='active'><a href='index.php'><span>Home</span></a></li>
   <li><a href='#step1'><span>Personal</span></a></li>
   <li><a href='#step2'><span>Address</span></a></li>
   <li><a href='#step3'><span>Contact</span></a></li> -->
  <?php  //$this->get_nav(); ?>
</ul>
</div>
          </aside>
         <div class="stepquestion">
         <span class="stepquestionheader"><h3><?php echo $this->category;?></h3></span>
         <span class="question">
          <h3><?php echo $this->step_weight;?>. <?php echo $this->step_question;?></h3>
          <form name="step<?php echo $this->step_weight;?>" id="form_step<?php echo $this->step_weight;?><?php echo $this->step_flags;?>" method="POST" action="index.php" >
            <input type="hidden" name="formname" value="step<?php echo $this->step_weight;?><?php echo $this->step_flags;?>"/>
            <?php $this->get_elements($this->step_id);?>
            <br/><br/>

           <hr/>

            <span class="bottombuttons">
                <span class="half">
                    <?php if ($this->step_weight>1){
                        echo "<input type='button' name='back' value='Back'  data-mini='true' data-theme='c' data-icon='carat-l' data-iconshadow='true' onclick='location.href=\"#step".($this->step_weight - 1).$this->step_flags."\";'/>";
                    }  ?>
                </span>
                <span class="half">
                    <input type="submit" data-mini="true" data-theme="c" data-icon="carat-r" data-iconpos="right" data-iconshadow="true" tabindex="<?php echo ($this->element_count+1);?>" name="step<?php echo $this->step_weight;?>" value="Next" onclick="savedata();">
                </span>
            </span>

          </form>
           </span>
           </div>


         </div>
          <div data-role="footer" style="text-align: center; width: 100%; position: absolute; bottom: 0px;"><br/>&copy;Homestar Financial 2016<br/><br/></div>
 </div>
