<div data-role="collapsible" data-collapsed="false">
   <h3>Application Info</h3>

     Status:&nbsp; <?php echo $this->app_status;?><br>
     Application Date: <?php echo $this->app_date;?><br>
</div>