<div class="summaryinfo">
<div data-role="collapsible" data-collapsed="false">
   <h3>Loan Info</h3>
   <a href="index.php#loaninfo" data-role="button" data-icon="grid" data-mini="true" style="width:4em; float: right;">Edit</a>



</div>

</div>