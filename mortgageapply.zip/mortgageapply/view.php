<div data-role="header">

        <h1>
       		View Submissions
        </h1>
</div>

     <div class="borrowertab">
        <?php include('tabs.html');?>
        <div style="clear: left;"></div>
          <?php
           require_once('classes/account.class.php');
           $account = new account;
          $account->check_loggedin(); ?>
		<div style="width: 75%; margin-left: auto; margin-right: auto;">
        <br/><span id="printer" style="width: 100%; text-align: right; float:right;"><a href="javascript:window.print()">
        <img src="img/printer.png" alt="print this page" id="print-button" style="width: 30px;"/></a>
        </span>
        <br/><br/>

		<?php

		include('classes/borrower.class.php');
		$borrower = new borrower;
        $borrower->view_my_applications();


        $borrower->create_borrower($_SESSION['fname'], $_SESSION['lname'], $_SESSION['middleinit'], $_SESSION['street'], $_SESSION['zip'], $_SESSION['city'], $_SESSION['state'], $_SESSION['mobilephone'], $_SESSION['homephone'], $_SESSION['email'], $_SESSION['dob']);
		$borrower->view_borrower();


        if ($_SESSION['coborrower']==true){
            include('classes/coborrower.class.php');
            $coborrower = new coborrower;
            $coborrower->create_coborrower($_SESSION['cofname'], $_SESSION['colname'], $_SESSION['comiddleinit'], $_SESSION['costreet'], $_SESSION['cozip'], $_SESSION['cocity'], $_SESSION['costate'], $_SESSION['comobilephone'], $_SESSION['cohomephone'], $_SESSION['coemail'], $_SESSION['codob']);
            $coborrower->view_coborrower();

        }
        include ('classes/loan.class.php');
        $loan = new loan;
        $loan->create_loan($_SESSION['cofname'], $_SESSION['colname'], $_SESSION['comiddleinit'], $_SESSION['costreet'], $_SESSION['cozip'], $_SESSION['cocity'], $_SESSION['costate'], $_SESSION['comobilephone'], $_SESSION['cohomephone'], $_SESSION['coemail'], $_SESSION['codob']);
        $loan->view_loan();







    ?>

		</div>
	</div>