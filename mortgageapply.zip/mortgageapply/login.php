<div data-role="header">
        <h1>
         Login
        </h1>
</div>
      <form name="login" id="loginform" action="<?php echo $_SERVER['PHP_SELF'];?>" method="POST">
        <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px;">
              <legend>Log In:</legend>
              <div class="leftcol">
               <label for="username">Username:<input type="text" name="username" id="username" placeholder="Username" maxlength="100" tabindex="1" required></label><br>
               <label for="password">Password:<input type="password" name="password" id="password" placeholder="Password" maxlength="100" tabindex="2" required></label><br>
               <input type="hidden" name="loginaccount" value="loginaccount"/>
              </div>
              <div class="rightcol">
                <a href="index.php#account" class="italic">Create an Account</a><br/>
                <a href="index.php#lost" class="italic">Lost Password</a>
              </div>
              <div class="leftcol">

              </div>

              <input type="submit" class="ui-btn ui-corner-all ui-btn-inline" value="Log in" name="submit" tabindex="3"/>


        </fieldset>

      </form>