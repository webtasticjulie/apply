<div data-role="header">

        <h1>
         Property Info
        </h1>
</div>


       <div class="progressbar">
            <div></div>
       </div>

      <div class="borrowertab">
        <?php include('tabs.html');?>
      	<div style="clear: left;"></div>
          <?php
           require_once('classes/account.class.php');
           $account = new account;
          $account->check_loggedin(); ?>
		<form name="loaninfo" method="post" action="index.php" style="padding: 20px;">
            <fieldset style="border: 2px solid #1E578E; padding: 2em; margin: .5em; ">
            <legend>Property Information</legend>
            <br/>
            <label for="propaddress">Address:<input type="text" maxlength="100" name="propaddress" id="propaddress" value="<?php echo $_SESSION['propaddress'];?>" title="Property Address" placeholder="Property Address"/></label>
            <label for="propcity">City:<input type="text" name="propcity" id="propcity" maxlength="100" value="<?php echo $_SESSION['propcity'];?>" title="Property City" placeholder="Property City" required/></label>
            <label for="propstate">State:

				<select name="propstate" data-mini="true" id="propstate" tabindex="6">
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Deleware</option>
                        <option value="FL">Florida</option>
                        <option value="GA" selected>Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                      </select></label>
            <label for="propzip">Zip Code:<input type="text" name="propzip" id="propzip" maxlength="25" value="<?php echo $_SESSION['propzip'];?>" title="Property Zip" placeholder="Zip code" required/></label>
            <label for="proptype">Property Type:
                <select name="proptype" id="proptype" data-mini="true" required>
                    <option value="">Select</option>
                    <option value="SingleFamily">Single Family</option>
                    <option value="Condominium">Condominium</option>
                    <option value="Townhouse">Townhouse</option>
                    <option value="Co-operative">Co-operative</option>
                    <option value="Two-to-four">Two-to-four unit property</option>
                    <option value="Multifamily">Multifamily</option>
                    <option value="Manufactured/Mobile Home">Manufactured/Mobile Home</option>
                    <option value="CommercialNon-Residental">Commerical/Non-Residental</option>
                    <option value="Mixed">Mixed Use- Residential</option>
                    <option value="Farm">Farm</option>
                    <option value="HomeBusinessComb">Home and Business Combined</option>
                    <option value="Land">Land</option>
                </select>
            </label>
            <label for="proprestype">Residency Type:
                <select name="proprestype" data-mini="true" id="proprestype" required>
                    <option value="">Select</option>
                    <option value="Primary">Primary</option>
                </select>
            </label>
            <label for="numunits">Number of Units:
            <input type="number" name="numunits" id="numunits" placeholder="###" value="<?php echo $_SESSION['numunits'];?>"/></label>
            <label for="salesprice">Sales Price:
            <input type="number" name="salesprice" id="salesprice" placeholder="###" value="<?php echo $_SESSION['salesprice'];?>"/></label>

            <label for="estimatedprice">Estimated Price:
            <input type="number" name="estimatedprice" id="estimatedprice" placeholder="###" value="<?php echo $_SESSION['estimatedprice'];?>"/></label>

            <label for="loanamount">Loan Amount:
            <input type="number" name="loanamount" id="loanamount" placeholder="###" value="<?php echo $_SESSION['loanamount'];?>"/></label>

            <label for="terms">Terms:</label>
            <select name="terms" id="terms">
            <option value="">Select</option>
            <option value="15">15</option>
            <option value="30">30</option>
            </select>

            <fieldset style="border: 1px solid #1E578E;padding: 2em; margin: 1em;">
            <legend>Title Information</legend><br/>
            Title will be held by
            <hr/>
           	<div class="leftcol">
            <label for="titleholder">Name #1:<input type="text" name="titleholder" id="titleholder" data-mini="true" title="Title Holder" placeholder="Title Holder"/></label>
            <label for="titleholder2">Name #2:<input type="text" name="titleholder2" id="titleholder2" data-mini="true" title="Title Holder #2" placeholder="Title Holder #2"/></label>

            </div>
            <div class="rightcol">
              <label for="manner">Manner:</label>
              <select name="manner" id="manner" data-mini="true">
              <option value="">Manner</option>
              <option value="manner">Manner #2</option>
              </select>
            </div>
            </fieldset>
            <fieldset style="border: 1px solid #1E578E;padding: 2em; margin: 1em;">
            <legend>Refinancing Information</legend>  <br/>
           	<div class="leftcol">
            <label for="yearsacquired">Years Acquired:</label><input type="text" name="yearsacquired" id="yearsacquired" title="Years Acquired" placeholder="Years Acquired" data-mini="true" value="<?php echo $_SESSION['yearsacquired'];?>"/>
            <label for="originalcost">Original Cost:</label><input type="number" name="originalcost" id="originalcost" data-mini="true" value="<?php echo $_SESSION['originalcost'];?>"/>
            <label for="existingloans">Amount of Existing Loans:</label><input type="number" name="existingloans" id="existingloans" data-mini="true" value="<?php echo $_SESSION['existingloans'];?>"/>
            <label for="refinancepurpose">Purpose of Refinance:</label>
            <select name="refinancepurpose" id="refinancepurpose">
            <option value="select">Select</option>
            </select>
            </div>
            <div class="rightcol">
            <label for="currentrate">Current Rate:</label><input type="text" name="currentrate" id="currentrate" data-mini="true" title="Current Rate" placeholder="Current Rate"/>
            <label for="curloantype">Current Loan Type: (i.e. 30 year fixed)</label><input type="text" name="curloantype" data-mini="true" id="curloantype" maxlength="40" value="<?php echo $_SESSION['curloantype'];?>" title="Current Loan Type" placeholder="Current Loan Type"/>
            <label for="curlender">Current Lender:</label><input type="text" name="curlender" id="curlender" data-mini="true" value="<?php echo $_SESSION['curlender'];?>" title="Current Lender" placeholder="Current Lender"/>
            </div>
            </fieldset>
			<input type="hidden" name="formname" value="loaninfo"/>
	        <input type="submit" name="submit" value="Next"/>
            </fieldset>
		</form>
	  </div>

