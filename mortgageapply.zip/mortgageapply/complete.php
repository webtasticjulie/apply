<div data-role="header">
        <h1 style="font-size: 2em; color: #1E578E;">
            Homestar
        </h1>
</div>
<br/>
<div class="progressbar">
        <div></div>
</div>

<div class="borrowertab">
      <?php include('tabs.html');?>
      <div style="clear: left;"></div>
      <strong style="display:block; padding: 10px;">Thank you for your submission.</strong>
      <?php
       require_once('classes/borrower.class.php');

	   $borrower = new borrower;
       //$app_id = $borrower->add_application('complete');
       //$borrower->add_borrower($_SESSION['fname'], $_SESSION['lname'], $_SESSION['middleinit'], $_SESSION['street'], $_SESSION['zip'], $_SESSION['city'], $_SESSION['state'], $_SESSION['mobilephone'], $_SESSION['homephone'], $_SESSION['email'], $_SESSION['dob'],'n', $app_id);

       if ($_SESSION['coborrower']=="yes"){
            $coborrower = new borrower;
            //$coborrower->add_borrower($_SESSION['cofname'], $_SESSION['colname'], $_SESSION['comiddleinit'], $_SESSION['costreet'], $_SESSION['cozip'], $_SESSION['cocity'], $_SESSION['costate'], $_SESSION['comobilephone'], $_SESSION['cohomephone'], $_SESSION['coemail'], $_SESSION['codob'],'y', $app_id);
       }
       include('tasks.php');
      ?>
</div>