    $(document).on('pagecreate', '#applypage' ,function(){
	     // Change width of progress bar
		$(".progressbar>div").css("width", "2%");
	});
	$(document).on('pagecreate', '#loaninfo' ,function(){
		// Change width of progress bar
		$(".progressbar div").css("width", "10%");

    });
	$(document).on('pagecreate', '#coborrowerpage' ,function(){
		// Change width of progress bar
		$(".progressbar div").css("width", "15%");
  	});
	$(document).on('pagecreate', '#personal' ,function(){
	 	// Change width of progress bar
		$(".progressbar div").css("width", "20%");
  	});
	$(document).on('pagecreate', '#employment' ,function(){
	    // Change width of progress bar
		$(".progressbar div").css("width", "30%");
  	});
	$(document).on('pagecreate', '#assets' ,function(){
	 	// Change width of progress bar
		$(".progressbar div").css("width", "40%");
  	});
	$(document).on('pagecreate', '#declarations' ,function(){
		// Change width of progress bar
		$(".progressbar div").css("width", "55%");
  	});
	$(document).on('pagecreate', '#consent' ,function(){
		// Change width of progress bar
		$(".progressbar div").css("width", "80%");
  	});
	$(document).on('pagecreate', '#summary' ,function(){
	    // Change width of progress bar
		$(".progressbar div").css("width", "100%");
  	});


    $("#coborrowerpage").on("pagebeforecreate", function(){
        $(".progressbar div").css("width", "15%");
    });

    $("#loaninfo").on( "pagebeforecreate", function() {
      	$(".progressbar div").css("width", "10%");
    });








