$( document ).ready(function() {

$("#addmore").on("click", function(){
         addMoreRows(this.form);
});
$("#removerows").on("click", function(){
    removeRow(this);
});

$("#copyborrower").on("click", function(){
    $("#costreet").val($("#street").val());
    $("#cocity").val($("#city").val());
    $("#cozip").val($("#zip").val());


});


//document.getElementById("optout").checked = false;

});

/*$(document).on("pagecreate","#applypage",function(){ // When entering pagetwo
  alert("applypage is about to be shown");

});     */

/*$(document).on("pagebeforeshow","#assets",function(){ // When entering pagetwo
  alert("asset is about to be shown");
});
$(document).on("pageshow","#assets",function(){ // When entering pagetwo
  alert("asset is now shown");
});
$(document).on("pagebeforehide","#assets",function(){ // When leaving pagetwo
  alert("asset is about to be hidden");
});
$(document).on("pagehide","#assets",function(){ // When leaving pagetwo
  alert("asset is now hidden");
});   */
function changePages(div){

$(div).css({ overflow:"auto" });
            $(':mobile-pagecontainer').pagecontainer('change', div, {
            transition: 'slide',
            changeHash: false,
            reverse: false,
            showLoadMsg: true
});
}