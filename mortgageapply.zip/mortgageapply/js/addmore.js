
    var rowCount = 1;
    function addMoreRows(frm) {
       var rowCount = $('#assets tr').length;
        var myclone = $('#cloneme').clone();
        myclone.find("#institutionname").attr("id", "institutionname"+rowCount);
        myclone.find("#account_types").attr("id", "account_types"+rowCount);
        myclone.find("#accountnumber").attr("id", "accountnumber"+rowCount);
        myclone.find("#balance").attr("id", "balance"+rowCount);
        myclone.appendTo("#addedRows");


    }
    function addMoreRaRows(frm) {
        rowCount = $('.assettable .row').length + 1;
        var myclone = $("#clone").clone();
        myclone.attr("id", "newId").find("#input_1").attr("id", "input_2");
        myclone.find("#asset_address0").attr("id","asset_address"+rowCount);
        myclone.find("#asset_city0").attr("id", "asset_city"+rowCount);
        myclone.find("#market_value0").attr("id", "market_value"+rowCount);
        myclone.find("#mortgageamt0").attr("id", "mortgageamt"+rowCount);
        var recRow = "<span id='rowCount" + rowCount + "' class='row'>"+ myclone.html() + "<span class='tablecell' style='width: 100%;'></span></span>";
        $('#addedRowsRA').append(recRow);

    }
    function removeRow() {
       var numItems = $('#assets tr').length;

       if (numItems >=3){  //check to ensure we are not removing last row item
            $('#assets tr:last').remove();  // remove last row of the assets table
       }else{
           alert('Sorry. You cannot remove the last row');
           //$.mobile.changePage( "#myDialog", { role: "dialog" } );
          // $( ":mobile-pagecontainer" ).pagecontainer( "change", "dialog.html", { role: "dialog" } );

       }

    }
     function removeRARow() {
         var numItems = $('.assettable .row').length + 1;
         if (numItems>=2){
            $(".assettable .row:last").remove();
         }else{
           alert('Sorry. You cannot remove the last row');
         }

    }
    function hideme(div){
          if ($("#optout").is(':checked')){
              $(div).hide();
          }else{
              $(div).show();
          }
    }




