function validate_number(input_name, error_div) {


       // input to validate
       var var_input = document.getElementById(input_name);
       // EM name to display error message
       var var_error_div = document.getElementById(error_div);

       //check that the input exists
       if(var_input.value == null) {
         var_error_div.innerHTML="element does not exist";
       }

         //not empty
         else if(var_input.value =="") {
         var_error_div.innerHTML="no input provided";
         var_error_div.style.backgroundColor="yellow";
       }

         //is a number
         else if(isNaN(var_input.value)) {
         var_error_div.innerHTML ="not a number";
         var_error_div.style.backgroundColor="yellow";

       }

         //with value between -100 and 100
         else if(var_input.value < 0 ) {
         var_error_div.innerHTML ="number is not a positive number";
         var_error_div.style.backgroundColor="yellow";
       } else  {

    //display checked next to validated field and calculate the result
       var_error_div.innerHTML ="checked";

    }
}