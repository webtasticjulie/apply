
<div data-role="header">
        <h1>
          Co-Borrower
        </h1>
</div>

       <div class="progressbar">
            <div></div>
        </div>
           <?php include('tabs.html');?>
        <div style="clear: left;"></div>
       

      <form name="coborrower" id="coborrowerform" action="index.php" method="POST" data-transition="slide">

        <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px;">

          <legend>Co-Borrower Info:</legend>
          <div class="leftcol">

            <label for="cofname">First Name:</label> <input type="text" placeholder="First Name" id="cofname" name="cofname" data-mini="true" required value="<?php echo $_SESSION['cofname'];?>"><br>
            <label for="comiddleinit">Middle Initial:</label><input type="text" placeholder="Middle Initial" id="comiddleinit" data-mini="true" name="comiddleinit" value="<?php echo $_SESSION['comiddleinit'];?>" required><br>
            <label for="colname">Last Name:</label><input type="text" placeholder="Last Name" name="colname" id="colname"  data-mini="true" value="<?php echo $_SESSION['colname'];?>"  required><br>
            <div id="CopyBorrower"><a href="#" id="copyborrower" style="float: right;">Copy Borrower Info</a></div><br/>
            <label for="costreet">Street:</label><input type="text" placeholder="Street" name="costreet" id="costreet" data-mini="true" value="<?php echo $_SESSION['costreet'];?>"  required><br>
            <label for="cocity">City:</label><input type="text" placeholder="City" name="cocity" id="cocity" data-mini="true" value="<?php echo $_SESSION['cocity'];?>"  required><br>
            	<select name="costate" data-mini="true" id="costate">
                        <option value="">Select</option>
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Deleware</option>
                        <option value="FL">Florida</option>
                        <option value="GA">Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                      </select>
            <label for="cozip">Zip:</label><input type="text" placeholder="Zip" name="cozip"  id="cozip" data-mini="true" value="<?php echo $_SESSION['cozip'];?>"  required size="10"><br>
          </div>
          <div class="rightcol">
            <label for="cohome">Home Phone:</label><input type="tel" name="cohome" id="cohome" data-mini="true" value="<?php echo $_SESSION['cohome'];?>"  required><br>
            <label for="comobile">Mobile Phone:</label><input type="tel" name="comobile" id="comobile" data-mini="true" value="<?php echo $_SESSION['comobile'];?>"  required><br>
            <label for="coemail">Email:</label> <input type="email" name="coemail" id="coemail" data-mini="true" value="<?php echo $_SESSION['coemail'];?>" ><br>
            <label for="codob">Date of birth:</label> <input type="date" name="codob" id="codob" data-mini="true" value="<?php echo $_SESSION['codob'];?>" >
            <label for="coyearscurrent">Years at Current Location:</label><input type="number" name="coyearscurrent" data-mini="true"  id="coyearscurrent" value="<?php echo $_SESSION['coyearscurrent'];?>"  required/>
            <label for="coownstatus">Own or Rent?:
            <label><input type="radio" name="coownstatus" value="Own" data-mini="true"/>Own</label>
            <label><input type="radio" name="coownstatus" value="Rent" data-mini="true"/>Rent</label>
            </label>

          </div>
           <br/>



        </fieldset>
        <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">

            <legend>Assets and Income</legend>
            <div class="leftcol">

                  <label for="cogross">Monthly Income: (Gross)</label><input type="number" name="cogross" required>  <br/>
                  <label>Sources of Income:</label><br/>
                  <label><input type="checkbox" name="cosources" data-mini="true" value="Self Employed">Self Employed</label>
                  <label><input type="checkbox" name="cosources" data-mini="true" value="Commissions"/>Commissions</label>
                  <label><input type="checkbox" name="cosources" data-mini="true" value="Salary"/>Salary</label>
                  <label><input type="checkbox" name="cosources" data-mini="true" value="Hourly"/>Hourly</label>
                  <label><input type="checkbox" name="cosources" data-mini="true" value="Other"/>Other</label><br/> <br/>
              </div>
              <div class="rightcol">
                  <label for="coemployer">Employer:</label> <input type="text" name="coemployer"/>
                  <label for="cojobtitle">Job Title:</label> <input type="text" name="cojobtitle"/>
                  <label for="coyearsposition">Years at Position:</label> <input type="text" name="coyearsposition"/>
                  <fieldset style="border: 1px inset navy; border-radius: 5px; margin: 20px; padding: 15px;">
                  <legend>Assets</legend><br/>
                  Checking/Savings: <input type="text" name="cocheckingsavings"/>
                  Real Estate:  <input type="text" name="corealestate"/>
                  Other:   <input type="text" name="coother"/>
                  </fieldset>
              </div>
        </fieldset>
        <input type="hidden" name="formname" value="coborrowerinfo"/>
        <input type="submit" value="Next"  class="ui-btn ui-corner-all ui-btn-inline ui-btn ui-corner-all ui-btn-inline" />


      </form>
