
        <div data-role="content">
            <div class="stepquestion">
         <span class="stepquestionheader"><h3>Coborrower</h3></span>
         <span class="question">
           <p>Before we begin the application, please answer:</p>
             <form name="coborrower"  name="step0" id="form_step0" method="POST" action="" >
                 <input type="hidden" name="formname" value="step0"/>
                 <label for="coborroweropt">Will you have a coborrower?
                     <span style="float:right;">
                        <select data-role="slider" id="coborroweropt" name="coborroweropt">
                            <option value="c">Yes</option>
                            <option value="a">No</option>
                        </select>
                     </span>
                      <br/><br/><br/>
                     <hr/>
                 </label>
                 <input type="submit" name="coborroweroption" value="Continue"/>
             </form>
             </span>
             </div>
         </div>
         
